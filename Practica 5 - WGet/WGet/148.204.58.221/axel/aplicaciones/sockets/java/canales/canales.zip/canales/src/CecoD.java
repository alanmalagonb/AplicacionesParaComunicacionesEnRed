import java.net.*;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

public class CecoD {

    public static void main(String[] args) {
        try {
            // Crea un canal de datagrama no bloqueante
            DatagramChannel channel = DatagramChannel.open();
            channel.configureBlocking(false);

            // Crea la dirección del servidor y el puerto
            InetSocketAddress serverAddress = new InetSocketAddress("localhost", 9999);

            // Envía el mensaje al servidor
            String mensaje = "Hola, servidor!";
            ByteBuffer buffer = ByteBuffer.wrap(mensaje.getBytes());
            channel.send(buffer, serverAddress);

            // Prepara el buffer para recibir la respuesta
            ByteBuffer receiveBuffer = ByteBuffer.allocate(1024);
            channel.receive(receiveBuffer);

            // Procesa la respuesta del servidor
            receiveBuffer.flip();
            byte[] responseData = new byte[receiveBuffer.remaining()];
            receiveBuffer.get(responseData);
            String respuesta = new String(responseData);
            System.out.println("Respuesta del servidor: " + respuesta);

            // Cierra el canal
            channel.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
