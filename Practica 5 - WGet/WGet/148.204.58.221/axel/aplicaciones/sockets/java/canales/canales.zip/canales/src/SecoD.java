
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.charset.StandardCharsets;

public class SecoD {
    private static final int BUFFER_SIZE = 1024;
    private static final int PORT = 9999;

    public static void main(String[] args) {
        try {
            // Crear un canal de datagrama no bloqueante
            DatagramChannel channel = DatagramChannel.open();
            channel.configureBlocking(false);

            // Vincular el canal a un puerto local
            channel.bind(new InetSocketAddress(PORT));

            System.out.println("Servidor de eco UDP no bloqueante iniciado en el puerto " + PORT);

            ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);

            while (true) {
                buffer.clear();

                // Leer datos del canal en el búfer
                InetSocketAddress clientAddress = (InetSocketAddress) channel.receive(buffer);

                if (clientAddress != null) {
                    buffer.flip();
                    String message = StandardCharsets.UTF_8.decode(buffer).toString();
                    System.out.println("Mensaje recibido de " + clientAddress.getAddress() + ": " + message);

                    // Enviar el mensaje de vuelta al cliente
                    buffer.flip();
                    channel.send(buffer, clientAddress);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}